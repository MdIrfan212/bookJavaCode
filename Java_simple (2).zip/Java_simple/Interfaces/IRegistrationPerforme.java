package Interfaces;

import java.lang.*;
import Classes.*;

public interface IRegistrationPerforme {
    void register(String name, String password, String confirm_password,	String email,String dob,String gender,String customerType,String country,String age);
}
