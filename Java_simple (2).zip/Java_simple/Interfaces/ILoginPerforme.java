package Interfaces;

import java.lang.*;
import Classes.*;

public interface ILoginPerforme {
    void matchAdmin(String username, String password, String uType);
}
