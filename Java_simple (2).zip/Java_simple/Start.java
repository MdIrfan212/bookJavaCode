import Classes.*;
import Interfaces.*;
import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
public class Start 
{
	public static void main(String [] args)
	{
		Welcome Wc = new Welcome();
		Wc.show();
		//new Payment();
		//AddRecipe add = new AddRecipe();
		//add.show();
		//CustomerCreate CC = new CustomerCreate();
		//CC.show();
		//AdminCreate Ac = new AdminCreate();
		//Ac.show();
		
		//AddIndigrents Av =  new AddIndigrents();
		//Av.show();
		//CustomerView Cw = new CustomerView();
		//Cw.show();
		//ShowRecipeForPCustomer lg = new ShowRecipeForPCustomer();
		//lg.show();
	}
}